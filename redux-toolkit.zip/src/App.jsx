import React, { Component } from 'react';
import { connect } from 'react-redux';

class App extends Component {

  render() {
    return (
      <React.Fragment>
        App
      </React.Fragment>
    );
  }
}

const mapStateToProps = (store) => {
  return {
    store,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    // systemOpenMessage: (params) => dispatch(systemOpenMessage(params)),
  };
};

export default (
  connect(
    mapStateToProps,
    mapDispatchToProps
  )(App));
