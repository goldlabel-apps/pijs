// https://github.com/reduxjs/redux-toolkit/issues/121


import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import * as serviceWorker from './serviceWorker';
import {
    createAction,
    configureStore,
    getDefaultMiddleware,
    createReducer
} from '@reduxjs/toolkit'
import logger from 'redux-logger'
import { reduxBatch } from '@manaflair/redux-batch'
import { persistStore, persistReducer } from 'redux-persist'
import storage from 'redux-persist/lib/storage'
import { PersistGate } from 'redux-persist/integration/react'
import { Provider } from 'react-redux'
import { combineReducers } from "redux";

const persistConfig = {
    key: 'weather',
    storage,
}

const incrementVisits = createAction('SYSTEM/INCREMENT/VISITS')

const systemReducer = createReducer([], {
    [incrementVisits]: (state, action) => {
        return state;
    }
})
const reducers = combineReducers({
    systemReducer
})

const persistedReducer = persistReducer(persistConfig, reducers)

const middleware = [...getDefaultMiddleware(), logger]
const preloadedState = {
    system: {
        visits: 1
    },
}
const store = configureStore({
    reducer: persistedReducer,
    middleware,
    devTools: process.env.NODE_ENV !== 'production',
    preloadedState,
    enhancers: [reduxBatch]
})

let persistor = persistStore(store)

ReactDOM.render(
    <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
            <App />
        </PersistGate>
    </Provider>
    , document.getElementById('root'));
serviceWorker.unregister();