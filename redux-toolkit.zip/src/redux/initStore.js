const initStore = (payload) => {
    return { store: 123 }
}

export default initStore;